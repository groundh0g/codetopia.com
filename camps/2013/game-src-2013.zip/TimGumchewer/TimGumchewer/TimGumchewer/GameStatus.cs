﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimGumchewer
{
    enum GameStatus
    {
        WAITING,
        READY,
        PLAYING,
        GAME_OVER,
    }
}
