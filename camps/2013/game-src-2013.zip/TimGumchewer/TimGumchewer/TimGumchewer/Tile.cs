﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimGumchewer
{
    public class Tile
    {
        public TileType TileType;
        public PlayerStatus Tactic;
    }
}
