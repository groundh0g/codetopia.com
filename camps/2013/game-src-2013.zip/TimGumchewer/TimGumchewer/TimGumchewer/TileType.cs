﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimGumchewer
{
    public enum TileType
    {
        NORMAL,
        GUM,
        SAWS,
        SPIKE,
        FIRE,
    }
}
