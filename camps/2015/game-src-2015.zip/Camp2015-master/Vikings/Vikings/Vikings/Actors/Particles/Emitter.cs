﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vikings.Actors.Particles
{
    public class Emitter
    {
    }
}
