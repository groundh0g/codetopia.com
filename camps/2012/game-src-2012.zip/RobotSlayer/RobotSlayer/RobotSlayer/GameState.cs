﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotSlayer
{
    public enum GameState
    {
        SplashScreen,
        Initializing,
        Playing,
        GameOver,
    }
}
